package Package;
import java.io.*;

public class Obj implements Serializable{
	private static final long serialVersionUID = 1L;
	 int xi,yi,xj,yj,tp,sl=0,cl,id;
	 Obj() { }
	 
	 Obj(int a, int b, int c, int d, int t, int col, int ide) {
	  xi=a; yi=b; xj=c; yj=d; tp=t; cl=col; id=ide;}
	 
	 class ipair { 
	  int x,y;
	  ipair(int xx, int yy) { x=xx; y=yy; }
	 }
	 
	 int dist(ipair P, ipair Q) { return (int)Math.sqrt((P.x-Q.x)*(P.x-Q.x) + (P.y-Q.y)*(P.y-Q.y)); }
	 int segdist(int xp,int yp) { // distance from point to line segment (initial diagonal pair)
	 ipair I=new ipair(xi,yi), J=new ipair(xj,yj), P=new ipair(xp,yp);
	 return dist(I,P)>dist(J,P)? dist(J,P):dist(I,P);
}}