package Package;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;


public final class Pad extends Frame{

	public static void main(String[] args) {
		Pad sketch= new Pad();
		sketch.setSize(200,200);
		sketch.setVisible(true);
	}
	
	private static final long serialVersionUID = 1L;// Not sure what is this for but it is stopping the warnings 
	int type=100,dmin=999999,select=0,x0,y0,xp,yp,x01,y01,right_click=0,complete=0,color=0,id=0,id_check,id_check1,xm,ym,Move;
	ArrayList<Obj> objs = new ArrayList<Obj>();
	ArrayList<Obj> Robjs= new ArrayList<Obj>();
	
	Obj closest = new Obj();
	Pad(){
		
		//Button Container
		setTitle("Bhanu SkecthPad");
		setLayout(new FlowLayout(FlowLayout.LEFT));
		//setBackground(Color.yellow);
		
		//Button Container
		Panel ButtonContainer = new Panel();
		ButtonContainer.setLayout(new GridLayout(18, 1));	
		ButtonContainer.setBackground(Color.blue);
		this.add(ButtonContainer);
		
		//Color Container
		Panel ColorContainer = new Panel();
		ColorContainer.setLayout(new GridLayout(1, 3));	
		
		//Undo-Redo container
		Panel UnReContainer = new Panel();
		UnReContainer.setLayout(new GridLayout(1, 2));
			
		//Export & Import Container
		Panel ExImContainer =new Panel();
		ExImContainer.setLayout(new GridLayout(1,2));
		
		ButtonContainer.add(ExImContainer);
		//Save Button
		Button SavButton = new Button("Export");
		ExImContainer.add(SavButton);
		SavButton.addActionListener(e -> {FileRW file = new FileRW();RWPack pack = new RWPack();pack.saveList = objs;file.Write(pack);});
		SavButton.setBackground(Color.orange);

		//Load Button
		Button LodButton = new Button("Import");
		ExImContainer.add(LodButton);
		LodButton.addActionListener(e -> {FileRW file = new FileRW();RWPack pack= new RWPack();pack = file.Read();objs=pack.saveList;repaint();});
		LodButton.setBackground(Color.orange);
		
		ButtonContainer.add(UnReContainer);
		//Undo Button
		Button UnButton = new Button("Undo");
		UnReContainer.add(UnButton);
		UnButton.addActionListener(e -> {if(objs.size()!= 0) {
		id_check=objs.get(objs.size()-1).id;id_check1=id_check;
		while(id_check==id_check1) {
			Robjs.add(objs.get(objs.size()-1));
			objs.remove(objs.size()-1);repaint();
			if(objs.size()>0)
			id_check=objs.get(objs.size()-1).id;
			else
			break;
		}
		}});
		
		//Undo Button
		Button ReButton = new Button("Redo");
		UnReContainer.add(ReButton);
		ReButton.addActionListener(e -> {if(Robjs.size()!= 0){ 
		id_check=Robjs.get(Robjs.size()-1).id;id_check1=id_check;
		while(id_check==id_check1) {
		 objs.add(Robjs.get(Robjs.size()-1));repaint();
		 Robjs.remove(Robjs.size()-1);
		 if(Robjs.size()>0)
		 id_check=Robjs.get(Robjs.size()-1).id;
		 else
		 break;
		}
		}});
		 
		//Line Button
		Button LinButton = new Button("Line");
		ButtonContainer.add(LinButton);
		LinButton.addActionListener(e -> type=0);
		
		//Rectangle Button
		Button RecButton = new Button("Rectangle");
		ButtonContainer.add(RecButton);
		RecButton.addActionListener(e -> type=1);
		
		//Circle Button
		Button CirButton = new Button("Circle");
		ButtonContainer.add(CirButton);
		CirButton.addActionListener(e -> type=2);
			
		//Ellipse Button
		Button EllButton = new Button("Ellipse");
		ButtonContainer.add(EllButton);
		EllButton.addActionListener(e -> type=3);
		
		//Square Button
		Button SqButton = new Button("square");
		ButtonContainer.add(SqButton);
		SqButton.addActionListener(e -> {type=7;repaint();});
		
		//Free Hand Button
		Button FHButton = new Button("Free Hand");
		ButtonContainer.add(FHButton);
		FHButton.addActionListener(e -> type=4);
		
		//open polygon Button
		Button opolButton = new Button("Open Polygon");
		ButtonContainer.add(opolButton);
		opolButton.addActionListener(e -> type=5);
		
		//close polygon Button
		Button cpolButton = new Button("Close Polygon");
		ButtonContainer.add(cpolButton);
		cpolButton.addActionListener(e -> type=6);
		
		//clear Button
		Button clButton = new Button("Clear");
		ButtonContainer.add(clButton);
		clButton.addActionListener(e -> {objs.clear();repaint();});
		
		//selection Button
		Button selButton = new Button("Select");
		ButtonContainer.add(selButton);
		selButton.addActionListener(e -> {select=1;closest.sl=0;repaint();type=100;});
		
		//Move Button
		Button MovButton = new Button("Move");
		ButtonContainer.add(MovButton);
		MovButton.addActionListener(e -> Move=1 );
		
		//Cut Button
		Button CutButton = new Button("Cut");
		ButtonContainer.add(CutButton);
		CutButton.addActionListener(e -> {int i=objs.size();
		while(i>0){if(objs.get(i-1).sl==1) {
		Robjs.add(objs.get(i-1));objs.remove(objs.get(i-1));repaint();} i=i-1; if(i>objs.size()) break;}
		});
		
		//Paste Button
		Button PasButton = new Button("Paste");
		ButtonContainer.add(PasButton);
		PasButton.addActionListener(e -> {int i=Robjs.size();
		while(i>0){if(Robjs.get(i-1).sl==1) {
		objs.add(Robjs.get(i-1));Robjs.remove(Robjs.get(i-1));repaint();}i=i-1;	if(i>Robjs.size()) break;}
		repaint();});
		
		////Group Button
		Button GrpButton = new Button("Group");
		ButtonContainer.add(GrpButton);
		GrpButton.addActionListener(e -> {});
		
	   ////UnGroup Button
		Button UGrpButton = new Button("UnGroup");
		ButtonContainer.add(UGrpButton);
		UGrpButton.addActionListener(e -> {});
			
		ButtonContainer.add(ColorContainer);
		//Black color Button
		Button BKCButton = new Button("   ");
		ColorContainer.add(BKCButton);
		BKCButton.addActionListener(e -> color=0);//Black-0
		BKCButton.setBackground(Color.black);
		
		//Red color Button
		Button RCButton = new Button("  ");
		ColorContainer.add(RCButton);
		RCButton.addActionListener(e -> color=1);//Red-1
		RCButton.setBackground(Color.red);
		
		//Blue color Button
		Button BCButton = new Button("   ");
		ColorContainer.add(BCButton);
		BCButton.addActionListener(e -> color=2);//Blue-1
		BCButton.setBackground(Color.blue);
		
		//Mouse Listener:Pressed & Released
		addMouseListener(new MouseAdapter()   {
		public void mousePressed(MouseEvent e){
		if(e.getButton()==1 && Move==1) {xm=e.getX();ym=e.getY();}
		if(e.getButton()==1) {select=0;}	
		if(e.getButton()==3) {objs.forEach(obj -> {obj.sl=0;});repaint();select=0;}	
		if(type==5 && e.getButton()==3) {right_click=1;id=id+1;}
			
		else if(type==6 && e.getButton()==3) {right_click=1;x0=e.getX();y0=e.getY();objs.add(new Obj(x01,y01,x0,y0,type,color,id));
		complete=1;id=id+1;repaint();}
			
		else if(type==6 && e.getButton()==1){right_click=0;
		if(objs.size()==0) {x01=e.getX();y01=e.getY();}
		else if(complete==1 || objs.get(objs.size()-1).tp!=6) {x01=e.getX();y01=e.getY();complete=0;}
		x0=e.getX();y0=e.getY();
		objs.add(new Obj(x0,y0,x0,y0,type,color,id));}
			
		else {
		x0=e.getX();y0=e.getY();
		xp=x0;yp=y0;//scribble
		objs.add(new Obj(x0,y0,x0,y0,type,color,id));
		right_click=0;
		}}//end of Mouse press
		public void mouseReleased(MouseEvent e){if(type<=4 || type==7) {id=id+1;}}
		});//End of Mouse Listener
		
		//Mouse Motion Listener
		addMouseMotionListener(new MouseMotionAdapter(){
		public void mouseMoved(MouseEvent e) {
		if (select==1 && objs.size()!=0) {//nearest object
		objs.forEach(ob ->{
		ob.sl = 0;int d=ob.segdist(e.getX(),e.getY());
		if( dmin > d ) {closest=ob; dmin=d;}});
		closest.sl=1;
		objs.forEach(ob ->{if(ob.id==closest.id) ob.sl=1;});
		repaint();}
		
		if ((type==5||type==6)  && objs.size()!=0 && right_click==0) {//Polygon
			if(objs.get(objs.size()-1).tp==5 || objs.get(objs.size()-1).tp==6) {
			objs.remove( objs.size()-1 );	
			objs.add(new Obj(x0,y0,e.getX(),e.getY(),type,color,id));
			repaint();
			}}
		}//End of Mouse Moved
		
		public void mouseDragged(MouseEvent e){
		if(select==1) {select=0;xm=e.getX();ym=e.getY();}		
		if(objs.size()!=0 && Move==1) {objs.forEach(obj->{if(obj.sl==1) {
		obj.xi+=(e.getX()-xm);obj.yi+=(e.getY()-ym);obj.xj+=(e.getX()-xm);obj.yj+=(e.getY()-ym);repaint();
		}});xm=e.getX();ym=e.getY();}	
		if(type==4) {//free Hand
		objs.add(new Obj(xp,yp,e.getX(),e.getY(),type,color,id));
		xp=e.getX(); yp=e.getY();
		repaint();}
		else {
		if(objs.size()!=0) {	
		objs.remove( objs.size()-1 );	
		objs.add(new Obj(x0,y0,e.getX(),e.getY(),type,color,id));
		repaint();}
		}
		}//End of Mouse dragged
		});//End of Mouse Motion Listener
		
		//ToCloseFrame
		addWindowListener(new WindowAdapter() {
	        public void windowClosing(WindowEvent we) {
	            dispose();
	         }});//End of Close Frame
	}
	
	int max(int a,int b){return a>b ? a:b;}
	int min(int a,int b){return a>b ? b:a;}
	int abs(int a){return a>0 ? a : -a;}

    public void paint(Graphics g){ 
		   dmin=9999999;
		   objs.forEach(ob -> {
		   if (ob.sl==1) g.setColor(Color.GREEN);
		   if (ob.sl==0 && ob.cl==0) g.setColor(Color.BLACK);
		   if (ob.sl==0 && ob.cl==1) g.setColor(Color.RED);
		   if (ob.sl==0 && ob.cl==2) g.setColor(Color.BLUE);
		   if (ob.tp==0) g.drawLine(ob.xi,ob.yi,ob.xj,ob.yj);
		   if (ob.tp==1) g.drawRect(min(ob.xi,ob.xj),min(ob.yi,ob.yj),abs(ob.xi-ob.xj),abs(ob.yi-ob.yj));
		   if (ob.tp==2) g.drawOval(min(ob.xi,ob.xj),min(ob.yi,ob.xj),abs(ob.xi-ob.xj),abs(ob.xi-ob.xj));
		   if (ob.tp==3) g.drawOval(min(ob.xi,ob.xj),min(ob.yi,ob.xj),abs(ob.xi-ob.xj),abs(ob.xi-ob.xj)/2);
		   if (ob.tp==4 || ob.tp==5 || ob.tp==6) g.drawLine(ob.xi,ob.yi,ob.xj,ob.yj);
		   if (ob.tp==7) g.drawRect(min(ob.xi,ob.xj),min(ob.yi,ob.yj),abs(ob.yi-ob.yj),abs(ob.yi-ob.yj));
		   });}
    }