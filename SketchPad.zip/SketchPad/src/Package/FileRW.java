package Package;

import java.io.*;
import java.util.ArrayList;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileSystemView;

class RWPack implements Serializable {
    private static final long serialVersionUID = 1L;
    public ArrayList<Obj> saveList;
}

public class FileRW implements Serializable {
	private static final long serialVersionUID = 1L;
    public void Write(RWPack pack){
        JFileChooser file = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
        file.setDialogTitle("Bhanu Sketch - Save...");
        file.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        int returnValue = file.showSaveDialog(null);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            if (!file.getCurrentDirectory().isDirectory()) {
                return;
            }
        }
        
        try {
        String filename = file.getCurrentDirectory().getCanonicalPath() + "\\" + file.getSelectedFile().getName();
        FileOutputStream fStream = new FileOutputStream(filename);
        ObjectOutputStream oOutStream = new ObjectOutputStream(fStream);
        oOutStream.writeObject(pack);
        oOutStream.close();}
    	catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public RWPack Read() {
    	RWPack pack = null;
        JFileChooser file = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
        file.setDialogTitle("Bhanu Sketch - Load...");
        file.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        int returnValue = file.showSaveDialog(null);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            if (!file.getCurrentDirectory().isDirectory()) {
                return null;
            }
        }
        try {
        String filename = file.getCurrentDirectory().getCanonicalPath() + "\\" + file.getSelectedFile().getName();
        FileInputStream fStream = new FileInputStream(filename);
        ObjectInputStream oInStream = new ObjectInputStream(fStream);
        pack = (RWPack) oInStream.readObject();
        oInStream.close();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return pack;
    }}